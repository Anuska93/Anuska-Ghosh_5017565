public interface PaymentStrategy {
    public void pay();
}
