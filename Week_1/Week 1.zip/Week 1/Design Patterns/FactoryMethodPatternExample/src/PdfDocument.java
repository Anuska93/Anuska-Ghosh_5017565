public class PdfDocument extends Document {
    public void disp(){
        System.out.println("Pdf Document Generated");
    }
    public void open(){
        System.out.println("Opening PDF Document...");
    }
    public void close(){
        System.out.println("Closing PDF Document...");
    }
    public void save(){
        System.out.println("Svaing PDF Document...");
    }
}
