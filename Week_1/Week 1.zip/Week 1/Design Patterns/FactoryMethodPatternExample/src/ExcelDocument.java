public class ExcelDocument extends Document {
    public void disp(){
        System.out.println("Excel Document Generated");
    }
    public void open(){
        System.out.println("Opening Excel Document...");
    }
    public void close(){
        System.out.println("Closing Excel Document...");
    }
    public void save(){
        System.out.println("Svaing Excel Document...");
    }
}
