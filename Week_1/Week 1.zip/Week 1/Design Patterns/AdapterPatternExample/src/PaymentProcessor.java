public interface PaymentProcessor{
    void processPayment();
    void success();
    void amount();
}